# An experimental subpolicy enabling
# some of the currently available post-quantum and hybrid algorithms.
# Not for production use.
# May disappear with the next update.

# More experimental
group = +P521-MLKEM1024
group = +MLKEM1024
group = +X448-MLKEM768
group = +P384-MLKEM768
group = +MLKEM768
group = +X25519-MLKEM512
group = +P256-MLKEM512
group = +MLKEM512
# re-prioritizing the ones from the base policies
group = -MLKEM768-X25519 -P256-MLKEM768 -P384-MLKEM1024 -MLKEM1024-X448
# More stable
group = +MLKEM1024-X448
group = +MLKEM768-X25519
group = +P384-MLKEM1024
group = +P256-MLKEM768
group = +MLKEM768-X25519

# More experimental
sign = +MLDSA87-P384
sign = +P521-MLDSA87
sign = +MLDSA65-P256
sign = +MLDSA65-RSA3072
sign = +MLDSA65-PSS3072
sign = +P384-MLDSA65
sign = +MLDSA44-P256
sign = +MLDSA44-ED25519
sign = +MLDSA44-RSA2048
sign = +MLDSA44-PSS2048
sign = +RSA3072-MLDSA44
sign = +P256-MLDSA44
# re-prioritizing the ones from the base policies
sign = -MLDSA44 -MLDSA65 -MLDSA87 -MLDSA65-ED25519 -MLDSA87-ED448
# More stable
sign = +MLDSA87-ED448
sign = +MLDSA65-ED25519
sign = +MLDSA87
sign = +MLDSA65
sign = +MLDSA44

key_exchange = +KEM-ECDH
