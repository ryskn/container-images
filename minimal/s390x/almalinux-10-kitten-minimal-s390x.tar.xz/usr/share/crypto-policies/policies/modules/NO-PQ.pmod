# A subpolicy that's meant to disable everything TEST-PQ enables.
# Can also be used with LEGACY/DEFAULT/FUTURE to disable just the PQ algorithms.

# %suppress_experimental_value_warnings=true

group = -*MLKEM*

sign = -*MLDSA*

# %suppress_experimental_value_warnings=false

key_exchange = -KEM-ECDH

